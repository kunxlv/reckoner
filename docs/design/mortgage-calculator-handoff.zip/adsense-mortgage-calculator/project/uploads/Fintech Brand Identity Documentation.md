---
name: Fintech App — Brand Identity & Design Tokens
derived_from: squarespace.com (marketing surface)
spec_format: DESIGN.md
status: draft v1 — needs a product name and a mark
audience: design tools, AI coding agents, human designers
---

# Brand Identity — Fintech App

**How to use this file.** Drop it at the repo root as `DESIGN.md`. Feed it to a design tool, Claude Code, Cursor, or v0 as the sole source of truth for visual decisions. Every token below is a literal value ready to paste. Where a rule matters more than a value, it's written as a **Rule:** line — obey those over your own instincts.

---

## 1. The thesis

Squarespace's marketing surface is built on a single counterintuitive idea: **the brand owns almost no colour of its own.** Pure `#000000` and pure `#ffffff` carry the overwhelming majority of the page. The only chromatic hexes in the system — a cool sky blue and a warm citrus — appear exclusively inside footer gradients, never as fills, borders, or text. Customer photography provides all the colour; the brand's CSS provides only layout, type, and contrast.

Translated to fintech, that inversion becomes a genuine advantage rather than a borrowed style:

> **The money is the only thing on screen allowed to have colour.**

A monochrome chassis means a balance, a delta, a chart line, or a failed payment is the single chromatic event in the viewport. Nothing competes with it. Restraint reads as competence, and competence is the entire product promise of a financial app.

Three inherited traits carry the personality:

- **Display type at the lightest weight, not the heaviest.** A 64px headline at weight 300 with aggressively negative tracking. Confidence expressed as thinness — the opposite of the bold-black-sans default every fintech reaches for.
- **A single italic serif moment.** One serif italic style, used only in section breaks. It is the entire warmth budget of the system. Spend it once per screen, never twice.
- **Hairlines instead of shadows.** Structure comes from 1px rules, not elevation. Cards are defined by outline, not by float.

---

## 2. Provenance and honest caveats

Read this section before you build. Three things about the "exact copy" brief need saying plainly.

**The typeface cannot be copied.** Squarespace runs `Clarkson` and `Clarkson Serif` — a custom neo-grotesque commissioned from type designer François Rappo and Optimo Type Foundry, built specifically for the brand. It is not licensable. Section 4 gives substitutes chosen for the same structural qualities (tight apertures, cut terminals, a neo-grotesque skeleton that survives weight 300 at display sizes). The substitution is where the identity will differ most visibly from the original, and there is no way around it.

**Copying a brand identity 1:1 carries real legal exposure.** Colour values, spacing grids, and radius scales aren't protectable — those are the parts this file reproduces faithfully. Logos, wordmarks, custom typefaces, illustration systems, and the overall trade dress are. A fintech app that reads as *"Squarespace but for money"* invites a passing-off or trademark complaint, and financial services is a sector where brand-confusion claims get taken seriously by regulators as well as courts. Take the system's architecture; build your own mark, your own photography direction, and your own wordmark.

**The monochrome premise partially breaks in fintech.** Squarespace can be colourless because user photography does the chromatic work. Your content is numbers, charts, and status. So this file inherits the palette exactly, then adds a deliberately minimal semantic layer (Section 3.3) — four hues, all desaturated and ink-adjacent so they read as part of the monochrome system rather than bolted onto it. Everything marked **[EXT]** is an extension I've added for fintech; everything unmarked is inherited.

**Source and freshness.** Token values below were extracted from the squarespace.com marketing page as of a May 2026 audit, cross-checked against the live page (July 2026 — hero, band structure, and footer gradient all still match). Squarespace maintains a public brand site at `brand.squarespace.com`; check it before finalising anything, since it will be more current than any third-party extraction.

---

## 3. Colour

### 3.1 Core — inherited exactly

| Token | Hex | Role |
|---|---|---|
| `--primary` | `#000000` | Primary action, brand chrome, strong hairlines |
| `--on-primary` | `#ffffff` | Text/icon on primary |
| `--canvas` | `#ffffff` | Page background, card background |
| `--canvas-inverse` | `#000000` | Inverted band background |
| `--surface-inverse` | `#000000` | Inverted card/panel |
| `--surface-mute` | `#2f2f2f` | Muted panel on dark, hover state for primary |
| `--ink` | `#000000` | Headlines, body text |
| `--ink-deep` | `#2f2f2f` | Secondary text, de-emphasised headings |
| `--ink-mid` | `#5a5a5a` | Captions, metadata |
| `--ink-mute` | `#898989` | Placeholder, disabled text |
| `--on-ink` | `#ffffff` | Text on dark surfaces |
| `--link` | `#0072f0` | Inline links |
| `--focus-ring` | `#0072f0` | Keyboard focus outline |
| `--hairline` | `#dddddd` | Default dividers, input borders |
| `--hairline-strong` | `#000000` | Emphasised rules, active outlines |
| `--hairline-soft` | `#dddddd` | Subtle internal dividers |
| `--gradient-sky` | `#88bcd8` | Gradient anchor only |
| `--gradient-citrus` | `#f3ffc1` | Gradient anchor only |

**Rule:** There are **no grey midtones** between `#ffffff` and `#2f2f2f` in the surface palette. Do not invent `#f5f5f5` "subtle background" fills. If you need to separate two areas, use a hairline. This is the single most-violated rule when an agent builds from this file.

**Rule:** `--gradient-sky` and `--gradient-citrus` appear **only inside linear gradients**, and only in the footer or one full-bleed marketing band. Never as a text colour, fill, border, chip, or icon.

```css
/* The only sanctioned chromatic surface in the system */
background: linear-gradient(160deg, #88bcd8 0%, #f3ffc1 100%);
```

### 3.2 Contrast pairings

| Foreground | On | Ratio | Verdict |
|---|---|---|---|
| `#000000` | `#ffffff` | 21.0:1 | AAA |
| `#2f2f2f` | `#ffffff` | 12.6:1 | AAA |
| `#5a5a5a` | `#ffffff` | 7.0:1 | AAA |
| `#898989` | `#ffffff` | 3.5:1 | **Large text / disabled only** |
| `#0072f0` | `#ffffff` | 4.6:1 | AA body, not AAA |
| `#ffffff` | `#000000` | 21.0:1 | AAA |
| `#dddddd` | `#ffffff` | 1.3:1 | Non-text (borders) only |

**Rule:** `--ink-mute` (`#898989`) never carries a monetary value, a status word, or anything a user must read to make a financial decision. Placeholders and disabled labels only.

### 3.3 Semantic layer **[EXT]**

Four hues, tuned dark enough to pass AA as text on white, and desaturated so they sit inside the monochrome discipline rather than shouting over it.

| Token | Light hex | On-white ratio | Dark-mode hex | Role |
|---|---|---|---|---|
| `--positive` | `#0f7a4d` | 5.4:1 | `#3ecf8e` | Credit, gain, settled, verified |
| `--negative` | `#c2321f` | 5.6:1 | `#ff6f5e` | Debit, loss, declined, breach |
| `--warning` | `#8a5a00` | 5.9:1 | `#e0a92a` | Pending, action required, limit near |
| `--info` | `#0072f0` | 4.6:1 | `#6aa9ff` | Neutral notice (reuses the inherited link blue) |

Low-emphasis tint fills, for chip backgrounds only:

| Token | Hex |
|---|---|
| `--positive-wash` | `#e8f5ee` |
| `--negative-wash` | `#fbeceb` |
| `--warning-wash` | `#f8f1e0` |
| `--info-wash` | `#e8f1fe` |

**Rule:** Colour is never the *only* carrier of financial meaning. A negative amount gets a minus sign or parentheses **and** the colour. A pending state gets the word "Pending" **and** the colour. Roughly 1 in 12 men has a red-green deficiency; a fintech app that encodes gain/loss in hue alone is a defect, not a style.

**Rule:** Chart series use `--ink`, `--ink-mid`, `--ink-mute`, then `--gradient-sky` as a fourth. Categorical data does not get the semantic palette — green and red mean money direction, always and only.

### 3.4 Dark mode **[EXT]**

The system already has both poles, so dark mode is a token swap rather than a redesign.

| Token | Light | Dark |
|---|---|---|
| `--canvas` | `#ffffff` | `#000000` |
| `--surface` | `#ffffff` | `#141414` |
| `--surface-mute` | `#2f2f2f` | `#2f2f2f` |
| `--ink` | `#000000` | `#ffffff` |
| `--ink-deep` | `#2f2f2f` | `#e4e4e4` |
| `--ink-mid` | `#5a5a5a` | `#a8a8a8` |
| `--ink-mute` | `#898989` | `#6e6e6e` |
| `--hairline` | `#dddddd` | `#2a2a2a` |
| `--hairline-strong` | `#000000` | `#ffffff` |
| `--primary` | `#000000` | `#ffffff` |
| `--on-primary` | `#ffffff` | `#000000` |

Note `#141414` is the one added surface value: pure-black cards on a pure-black canvas can't be separated by hairlines alone on OLED.

---

## 4. Typography

### 4.1 Substitution

The original runs `Clarkson` (sans) and `Clarkson Serif`, weights 300 / 400 / 500 only. Pick one row and commit.

| Tier | Sans | Serif italic | Notes |
|---|---|---|---|
| **Closest paid** | Söhne (Klim) or Suisse Int'l (Swiss Typefaces) | Signifier Italic (Klim) or Editorial New Italic | Söhne is the nearest available relative to Clarkson's cut neo-grotesque skeleton. Budget ~€300–600 for web licences. |
| **Open-source default** | Inter Variable — use `Inter Display` optical sizing at ≥32px | Instrument Serif Italic | Free, and Inter is the strongest open face for financial UI because of real tabular figures and slashed-zero alternates. **Recommended starting point.** |
| **Numeric / mono** **[EXT]** | Geist Mono or JetBrains Mono | — | Account numbers, IBANs, transaction references, API keys |

```css
--font-sans: "Inter", "Inter Variable", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
--font-display: "Inter Display", "Inter", sans-serif;
--font-serif: "Instrument Serif", Georgia, serif;   /* italic only */
--font-mono: "Geist Mono", "JetBrains Mono", ui-monospace, monospace;
```

**Rule:** Only weights **300, 400, 500** exist. There is no 600, no 700, no bold. If a hierarchy problem seems to need bold, it needs size or space instead. This single constraint does more to produce the look than any colour token.

**Rule:** Enable `font-feature-settings: "tnum" 1, "zero" 1;` globally on anything numeric. Non-tabular figures make a transaction list visibly jitter as values update, and an unslashed zero next to a capital O in a reference code is a support ticket.

### 4.2 Scale — 9 styles, inherited proportions

| Token | Size | Weight | Tracking | Line height | Family | Use |
|---|---|---|---|---|---|---|
| `display-xl` | 64px | 300 | −0.06em | 1.00 | display | Marketing hero, single per page |
| `display` | 48px | 300 | −0.05em | 1.05 | display | Section opener |
| `h1` | 40px | 400 | −0.03em | 1.10 | display | Screen title |
| `h2` | 32px | 400 | −0.025em | 1.15 | sans | Sub-section |
| `h3-serif` | 26px | 400 *italic* | −0.02em | 1.30 | **serif** | The one editorial break |
| `body-lg` | 20px | 400 | −0.01em | 1.50 | sans | Lede paragraph |
| `body` | 16px | 400 | 0 | 1.55 | sans | Default |
| `caption` | 14px | 400 | 0 | 1.45 | sans | Metadata, helper text |
| `label` | 12px | 500 | +0.08em, uppercase | 1.30 | sans | Eyebrows, table headers, form labels |

Mobile overrides: `display-xl` → 40px, `display` → 34px, `h1` → 28px, `h2` → 24px, `h3-serif` → 21px. Everything else holds.

### 4.3 Numeric styles **[EXT]**

The one genuine gap in the source system — Squarespace has no data typography because it displays no data.

| Token | Size | Weight | Tracking | Family | Use |
|---|---|---|---|---|---|
| `balance-hero` | 56px | 300 | −0.04em | display, `tnum` | The account balance. Inherits the weight-300 display logic. |
| `amount-lg` | 28px | 400 | −0.02em | sans, `tnum` | Card totals, transaction detail |
| `amount` | 16px | 500 | 0 | sans, `tnum` | Transaction row values |
| `amount-sm` | 14px | 500 | 0 | sans, `tnum` | Table cells, dense lists |
| `mono-id` | 13px | 400 | +0.02em | mono | IBAN, reference, last-4 |

**Rule:** Currency symbols and decimal minor units render at `--ink-mid`, one step down in size from the integer part. `€1,240` reads at full weight; `.50` and `€` sit back. This is what makes a balance feel designed rather than printed.

**Rule:** The serif italic (`h3-serif`) never appears inside a transaction list, table, or form. It belongs to marketing, onboarding, and empty states. One instance per screen, maximum.

---

## 5. Space and grid

4px base grid, leaning on a subset of steps.

| Token | Value |
|---|---|
| `--space-1` | 4px |
| `--space-2` | 8px |
| `--space-3` | 12px |
| `--space-4` | 16px |
| `--space-6` | 24px |
| `--space-8` | 32px |
| `--space-10` | 40px |
| `--space-16` | 64px |
| `--space-24` | 96px |

**Rule:** The workhorses are **8 / 12 / 16 / 24 / 32 / 40**. Reach for 4 only for icon-to-label gaps, and for 64 / 96 only for vertical band separation.

Layout: 12-column grid, 24px gutter, `--container-max: 1280px`, 24px page padding on mobile and 40px from `md` up. Section bands are full-bleed and alternate `--canvas` / `--canvas-inverse`; the alternation is the primary rhythm device of the system.

---

## 6. Radius — the twin chassis

| Token | Value | Applied to |
|---|---|---|
| `--radius-none` | 0 | Full-bleed bands, table cells, hairline dividers |
| `--radius` | **8px** | Cards, inputs, primary buttons, modals, chips-with-corners |
| `--radius-lg` | 30px | Large feature panels, image containers |
| `--radius-pill` | **100px** | Secondary CTA, status chips, tags, avatars-as-pill |
| `--radius-full` | 50% | Circular avatar, icon button |

**Rule:** There is nothing between 8px and 100px except the 30px feature panel. Do not use 4px, 6px, 12px, or 16px radii. The tension between a sharp 8px rectangle and a fully round pill sitting side by side in the same CTA group *is* the signature — softening either one collapses it.

---

## 7. Borders and elevation

```css
--border-hairline: 1px solid #dddddd;
--border-strong:   1px solid #000000;
--border-focus:    2px solid #0072f0;
```

**Rule:** **No shadows.** Cards, panels, dropdowns, and nav bars are defined by hairlines and background contrast. This is not negotiable — it's the load-bearing structural decision of the whole system.

The single exception **[EXT]**, because a modal genuinely needs to escape the page plane:

```css
--shadow-overlay: 0 24px 64px -12px rgba(0, 0, 0, 0.24);
```

Modals, sheets, and toasts only. Never cards, never buttons, never inputs.

---

## 8. Buttons

The twin-chassis pattern is most visible here, so this section is the most literal.

### 8.1 Shared geometry

| Size | Height | Padding X | Type | Icon gap |
|---|---|---|---|---|
| `sm` | 36px | 16px | 14px / 500 | 6px |
| `md` (default) | 44px | 20px | 16px / 500 | 8px |
| `lg` | 52px | 28px | 16px / 500 | 8px |

Shared: `font-family: var(--font-sans)`, no text-transform, no letter-spacing, `transition: background-color 160ms cubic-bezier(0.2,0,0,1), color 160ms`.

### 8.2 Variants

**Primary — the 8px rectangle**

```css
background: #000000;
color: #ffffff;
border: none;
border-radius: 8px;
/* hover  */ background: #2f2f2f;
/* active */ background: #000000; transform: translateY(1px);
/* disabled */ background: #dddddd; color: #898989; cursor: not-allowed;
```

**Secondary — the 100px pill**

```css
background: transparent;
color: #000000;
border: 1px solid #000000;
border-radius: 100px;
/* hover  */ background: #000000; color: #ffffff;
/* active */ background: #2f2f2f; border-color: #2f2f2f;
/* disabled */ border-color: #dddddd; color: #898989;
```

**Tertiary — text with an arrow**

```css
background: none; border: none; border-radius: 0;
color: #000000; padding: 0;
/* hover */ text-decoration: underline; text-underline-offset: 3px;
```

Squarespace's link CTAs almost all carry a trailing `→`. Inherit it: the arrow translates 2px on the x-axis on hover, and nothing else moves.

**Inverse — for use on `--canvas-inverse` bands**

```css
background: #ffffff; color: #000000; border-radius: 8px;
/* hover */ background: #dddddd;
```

**Destructive [EXT]** — irreversible money actions only (cancel a transfer, close an account, revoke a key)

```css
background: #c2321f; color: #ffffff; border-radius: 8px;
/* hover */ background: #a52918;
```

### 8.3 Rules

- Primary is `--radius` (8px). Secondary is `--radius-pill` (100px). **Never swap, never harmonise them.**
- One primary per view. Two primaries means the hierarchy isn't decided yet.
- Focus state on every variant: `outline: 2px solid #0072f0; outline-offset: 2px;` — and it must survive on the inverse band, so on `--canvas-inverse` the focus ring becomes `#ffffff`.
- Minimum touch target 44×44px. `sm` at 36px height needs 4px of transparent vertical padding to reach it.
- Labels are active verbs in sentence case: `Send money`, `Add account`, `Confirm transfer`. Never `Submit`, never `Click here`, never title case. The verb that starts the flow is the verb that confirms it — a `Send` button produces a `Sent` confirmation.

---

## 9. Inputs and forms

```css
height: 48px;
background: #ffffff;
border: 1px solid #dddddd;
border-radius: 8px;
padding: 0 16px;
font: 400 16px/1 var(--font-sans);
color: #000000;
/* placeholder */ color: #898989;
/* hover */  border-color: #898989;
/* focus */  border-color: #000000; outline: 2px solid #0072f0; outline-offset: 1px;
/* error */  border-color: #c2321f;
/* disabled */ background: #ffffff; border-color: #dddddd; color: #898989;
```

Label above the field, `label` style (12px / 500 / uppercase / +0.08em), 8px gap. Helper text below at `caption` / `--ink-mid`, 6px gap. Error text replaces helper text at `caption` / `--negative`, prefixed with a 14px icon.

**Rule:** 16px minimum font-size on all inputs. Anything smaller triggers iOS Safari's zoom-on-focus, which is a real bug in a payment flow.

**Currency input [EXT]:** symbol pinned left as a non-editable prefix at `--ink-mid`; value right-aligned in `amount-lg` with `tnum`; the field grows to 56px height. Format the thousands separator on blur, not on keystroke — live reformatting fights the caret.

**Error copy [EXT]:** state what happened and what to do, in the interface's voice, without apology. `Card declined. Try another card or contact your bank.` — not `Oops! Something went wrong.`

---

## 10. Fintech components **[EXT]**

**Balance card.** `--canvas`, 8px radius, 1px `--hairline`, 24px padding, no shadow. `label` eyebrow ("Available balance"), 8px gap, `balance-hero` value, 12px gap, delta row. Optional inverse variant on `--canvas-inverse` for the primary account — the band alternation logic applied at component scale.

**Delta row.** Caret glyph + signed value in `amount-sm` + period label at `caption` / `--ink-mid`. Colour from `--positive` / `--negative`. Sign always present.

**Transaction row.** 72px height, `--hairline` bottom border, no radius, no card. Left: 40px circular avatar or merchant initial on `--surface-mute`. Centre: merchant at `body`, category + time at `caption` / `--ink-mid`. Right: `amount`, right-aligned, `tnum`; debits get a leading `−`, credits get `+` and `--positive`. Hover: background `#fafafa`… **no** — hover is a 1px `--hairline-strong` top-and-bottom border instead. Keep the no-grey-midtones rule intact.

**Status chip.** `--radius-pill`, 24px height, 10px horizontal padding, `label` type, wash background + matching semantic text colour. Six states: Settled, Pending, Processing, Failed, Refunded, Scheduled.

**Data table.** Header row: `label` type, `--ink-mid`, 1px `--hairline-strong` bottom border. Body rows: 56px, `--hairline` separators, zero radius, no zebra striping. Numeric columns right-aligned with `tnum`. Sticky header at `--canvas`.

**Chart.** Axis lines `--hairline`. Gridlines horizontal only, `--hairline-soft`, no verticals. Primary series `--ink` at 1.5px. Area fill `rgba(0,0,0,0.06)`. Positive/negative bar charts use the semantic pair. No legend if one series. No gradients under lines. Tooltip: `--canvas`, 8px radius, 1px `--hairline-strong`, `--shadow-overlay`.

**Empty state.** The sanctioned home for the serif italic. `h3-serif` line, `body` / `--ink-mid` explanation, one secondary pill CTA. Empty is an invitation to act, so the copy names the action: *No transactions yet* → `Add your first account`.

---

## 11. Motion

```css
--ease: cubic-bezier(0.2, 0, 0, 1);
--dur-fast: 160ms;   /* hover, focus, colour */
--dur-base: 220ms;   /* enter/exit, expand */
--dur-slow: 400ms;   /* page band reveal, sheet */
```

Scroll-triggered band reveals: 16px translate-Y with opacity, staggered 60ms. Number transitions on balance change: count-up over 400ms, `tnum` prevents width jitter. Nothing bounces, nothing springs, nothing rotates. `@media (prefers-reduced-motion: reduce)` collapses all of it to opacity-only at 0ms.

---

## 12. Quality floor

- WCAG 2.1 AA minimum; AAA on any monetary figure.
- Visible keyboard focus on every interactive element, including on inverse bands.
- Responsive from 320px. Test the balance card and transaction row at 320px specifically — `balance-hero` at 56px overflows a 320px viewport with a five-figure balance plus currency symbol. Clamp it: `clamp(36px, 12vw, 56px)`.
- Every amount has a screen-reader-friendly form: `aria-label="minus 42 euros 50 cents"` beats letting a reader announce `−€42.50` as punctuation soup.
- Reduced motion, reduced transparency, and forced-colours modes all respected.

---

## 13. Voice

Editorial restraint, matched to the visual system. Plain verbs, sentence case, no filler, no exclamation marks.

| Do | Don't |
|---|---|
| Send money | Submit payment request |
| Card declined. Try another card. | Oops! Something went wrong 😔 |
| No transactions yet | Nothing to see here! |
| Available balance | Your amazing balance |
| Transfer scheduled for 3 Aug | Success! Your transfer has been successfully scheduled! |

Name things by what the person controls, never by how the system is built — *notifications*, not *webhook config*. Errors don't apologise and are never vague about what happened. Never imply guaranteed returns, and keep required regulatory disclosure at `caption` / `--ink-mid` rather than hiding it at `--ink-mute`.

---

## 14. Do / don't

| Do | Don't |
|---|---|
| Two-hex chrome; colour only on money | Add a brand accent hue "for personality" |
| Hairlines for all structure | Add card shadows |
| Weights 300 / 400 / 500 | Reach for 600 or 700 |
| 8px rectangle primary + 100px pill secondary | Give both buttons the same radius |
| Serif italic once per screen | Use it in tables or lists |
| Sky/citrus in footer gradients only | Use them as chips, links, or fills |
| Alternate white and black full-bleed bands | Introduce `#f5f5f5` section backgrounds |
| `tnum` on every figure | Ship proportional figures in a balance |

---

## 15. Export

### CSS custom properties

```css
:root {
  /* surface */
  --canvas: #ffffff;
  --canvas-inverse: #000000;
  --surface-inverse: #000000;
  --surface-mute: #2f2f2f;

  /* ink */
  --ink: #000000;
  --ink-deep: #2f2f2f;
  --ink-mid: #5a5a5a;
  --ink-mute: #898989;
  --on-ink: #ffffff;

  /* brand */
  --primary: #000000;
  --on-primary: #ffffff;
  --link: #0072f0;
  --focus-ring: #0072f0;

  /* hairlines */
  --hairline: #dddddd;
  --hairline-strong: #000000;
  --hairline-soft: #dddddd;

  /* gradient anchors — gradients only */
  --gradient-sky: #88bcd8;
  --gradient-citrus: #f3ffc1;

  /* semantic [EXT] */
  --positive: #0f7a4d;
  --negative: #c2321f;
  --warning: #8a5a00;
  --info: #0072f0;
  --positive-wash: #e8f5ee;
  --negative-wash: #fbeceb;
  --warning-wash: #f8f1e0;
  --info-wash: #e8f1fe;

  /* radius */
  --radius-none: 0;
  --radius: 8px;
  --radius-lg: 30px;
  --radius-pill: 100px;
  --radius-full: 50%;

  /* space */
  --space-1: 4px;  --space-2: 8px;   --space-3: 12px;
  --space-4: 16px; --space-6: 24px;  --space-8: 32px;
  --space-10: 40px; --space-16: 64px; --space-24: 96px;

  /* type */
  --font-sans: "Inter", -apple-system, BlinkMacSystemFont, sans-serif;
  --font-display: "Inter Display", "Inter", sans-serif;
  --font-serif: "Instrument Serif", Georgia, serif;
  --font-mono: "Geist Mono", ui-monospace, monospace;

  /* motion */
  --ease: cubic-bezier(0.2, 0, 0, 1);
  --dur-fast: 160ms;
  --dur-base: 220ms;
  --dur-slow: 400ms;

  --shadow-overlay: 0 24px 64px -12px rgba(0, 0, 0, 0.24);
  --container-max: 1280px;
}

* { font-feature-settings: "tnum" 1, "zero" 1; }
```

### Tailwind v4

```css
@import "tailwindcss";

@theme {
  --color-canvas: #ffffff;
  --color-canvas-inverse: #000000;
  --color-surface-mute: #2f2f2f;
  --color-ink: #000000;
  --color-ink-deep: #2f2f2f;
  --color-ink-mid: #5a5a5a;
  --color-ink-mute: #898989;
  --color-hairline: #dddddd;
  --color-link: #0072f0;
  --color-positive: #0f7a4d;
  --color-negative: #c2321f;
  --color-warning: #8a5a00;
  --color-info: #0072f0;
  --color-gradient-sky: #88bcd8;
  --color-gradient-citrus: #f3ffc1;

  --font-sans: "Inter", sans-serif;
  --font-display: "Inter Display", "Inter", sans-serif;
  --font-serif: "Instrument Serif", Georgia, serif;
  --font-mono: "Geist Mono", ui-monospace, monospace;

  --radius-DEFAULT: 8px;
  --radius-lg: 30px;
  --radius-pill: 100px;

  --ease-brand: cubic-bezier(0.2, 0, 0, 1);
}
```

**Rule for agents consuming this file:** do not extend the palette. If a design problem seems to need a colour that isn't listed, it needs a hairline, a size change, or more space. The absence of colour is the identity.

---

## 16. Open decisions

Four things this file can't decide for you:

1. **Product name and wordmark.** Squarespace's wordmark is set in its custom typeface — you can't inherit that, so the mark is entirely yours to make. Set it in your chosen sans at weight 400, tight tracking, lowercase, and resist adding a glyph unless the glyph earns its place.
2. **Typeface tier.** Section 4.1 offers three paths. Inter + Instrument Serif costs nothing and ships today; Söhne + Signifier gets closest to the original and costs a few hundred euro. Decide before any real design work, because the type choice changes every spacing value downstream.
3. **The photographic direction.** Squarespace's monochrome works because customer photography carries the colour. A fintech app has no equivalent content. Either commit to a real photographic system (people, physical objects, place — not stock finance abstractions) or accept that the app will be genuinely, almost entirely, black and white. Both are valid; the second is braver and cheaper.
4. **Regulatory chrome.** Depending on whether you're operating as an e-money institution, a payment institution, or an agent of one, the Central Bank of Ireland and PSD2/PSR requirements will dictate specific disclosure placement, consent-flow wording, and strong-customer-authentication screens. Those constraints override anything in this file. Get them from your compliance counsel before finalising the flows, not after.
