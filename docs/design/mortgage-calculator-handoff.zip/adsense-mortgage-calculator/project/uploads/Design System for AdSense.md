# Design System — Finance Calculator Hub

**Status:** authoritative. Do not substitute your own palette, typefaces, or motion choices.
**Applies to:** all calculators across the hub (mortgage first, ~20 tools to follow), all 12 country editions.

---

## 0. What this product is, and what it is not

**It is:** an ad-supported, SEO-dependent utility. A person arrives from a Google or ChatGPT result on a mid-range Android phone, wants one number, and will probably never return. Sessions are single-visit. Revenue comes from display ads whose slots must never shift.

**It is not:** a logged-in fintech app. Cred, Revolut, and Monzo are the aesthetic reference for *craft level* only — never for interaction model. They have returning users, no ads, no organic-search dependency, and can afford a 3-second animated entry. We cannot.

**Consequence:** every gram of "premium" is spent on typography, color discipline, spacing, and one high-craft chart. None of it is spent on motion, scroll effects, or JavaScript.

---

## 1. Design thesis

> **The calculation is the hero. Its two halves are the brand.**

Every mortgage is a fight between two numbers: the part you keep (principal, equity) and the part you lose (interest, cost). That relationship is the product's entire subject. So the palette isn't decoration applied on top of the data — the two data colors *are* the brand colors, and they mean the same thing in every tool in the hub forever.

**Signature element: The Crossover.** On a 30-year loan, the month where principal repayment overtakes interest lands around year 18. Nobody's bank shows them this. We mark it, label it in plain words, and it is the single animated moment on the page. Every tool gets one equivalent "moment" — the crossover is the flagship's.

**Aesthetic register:** a central-bank statistical publication redrawn by someone who cares. Authoritative, numerate, printed. Not an app. Not a dashboard. Not a SaaS landing page.

---

## 2. Color

Light mode is the primary theme and the default. Dark mode is secondary, shipped but not the showcase. (Light performs better with display ads and matches the printed-document register.)

### 2.1 Core tokens — light

| Token | Hex | Role |
|---|---|---|
| `--paper` | `#F8F8F6` | page background — cool off-white, not cream |
| `--surface` | `#FFFFFF` | result card, elevated panels |
| `--surface-sunken` | `#F1F1EE` | table stripes, disabled fields, ad slot resting state |
| `--ink` | `#14181C` | primary text, hero numerals, primary buttons |
| `--ink-muted` | `#5B6169` | labels, captions, helper text |
| `--ink-faint` | `#8B9198` | placeholders, axis ticks, disclaimers |
| `--rule` | `#E2E3DF` | 1px hairlines and borders |
| `--focus` | `#1F6FEB` | focus ring only — never decorative |

### 2.2 Data tokens — the brand

These are semantic across the entire hub. Never reassign them.

| Token | Hex | Always means |
|---|---|---|
| `--principal` | `#0E6B63` | deep teal — what you keep. Principal, equity, savings, growth |
| `--interest` | `#8C2F39` | oxblood — what it costs. Interest, fees, tax, loss |
| `--scenario` | `#C98A16` | saffron — what changes. Overpayments, comparisons, "what if" |
| `--principal-soft` | `#D9E8E6` | teal at fill opacity for area charts |
| `--interest-soft` | `#F2DEE0` | oxblood at fill opacity |
| `--scenario-soft` | `#F7EBD2` | saffron at fill opacity |

`--danger` = `#B3261E`, reserved **exclusively** for validation errors. It must never appear in a chart, or the user will read a normal loan as an alarm.

### 2.3 Dark mode

| Token | Hex |
|---|---|
| `--paper` | `#101314` |
| `--surface` | `#181C1E` |
| `--surface-sunken` | `#0B0E0F` |
| `--ink` | `#ECEEEC` |
| `--ink-muted` | `#9AA1A4` |
| `--rule` | `#2A2F31` |
| `--principal` | `#3FA396` |
| `--interest` | `#D4707B` |
| `--scenario` | `#E0AD4A` |

### 2.4 Color rules

- **One accent per screen.** `--ink` is the primary button. The data colors appear in the chart, the result figures, and nowhere else.
- **No gradients.** Not in backgrounds, not in text, not in charts, not in buttons.
- **No glassmorphism, no blur, no translucency.**
- Elevation is expressed by **1px `--rule` borders and background tint**, not shadows. One shadow token exists (`--shadow-pop`, `0 1px 2px rgba(20,24,28,.06), 0 8px 24px rgba(20,24,28,.06)`) for popovers and the sticky mobile result bar only.
- All text meets **WCAG 2.2 AA**: ≥4.5:1 body, ≥3:1 for text ≥24px. `--ink-faint` on `--paper` is for ≥16px only; never use it for anything a user must read to act.
- Never encode meaning in color alone. Chart series carry direct labels; validation carries an icon and text.

---

## 3. Typography

Two families. Both variable, both self-hosted via `next/font`, both subset to Latin.

| Role | Family | Why |
|---|---|---|
| **Display + all large numerals** | **Newsreader** (variable serif) | Serif numerals in a fintech context are unexpected and read as editorial authority rather than app chrome. This is the deliberate risk. |
| **UI, body, labels, tables** | **Public Sans** (variable grotesque) | Built for public-interest data, has true tabular lining figures, neutral without being Inter. |

**Inter is banned.** It is the single strongest tell of generated design. So are Poppins, Montserrat, and any pairing of a geometric sans with a script.

### 3.1 Numerals — non-negotiable

Every numeral in the interface, without exception:

```css
font-variant-numeric: tabular-nums lining-nums slashed-zero;
```

Digits must not reflow as the user drags a slider. Decimal points must align in every table column. This single rule does more for perceived quality than any animation.

### 3.2 Scale

| Token | Size | Family / weight | Use |
|---|---|---|---|
| `--t-hero` | `clamp(3rem, 11vw, 5.5rem)` | Newsreader 400, tracking `-0.02em` | the answer. One per page. |
| `--t-figure` | `clamp(1.75rem, 5vw, 2.5rem)` | Newsreader 400 | secondary results (total interest, payoff date) |
| `--t-h1` | `clamp(1.75rem, 4.5vw, 2.25rem)` | Public Sans 600 | page title |
| `--t-h2` | `1.375rem` | Public Sans 600 | section |
| `--t-h3` | `1.0625rem` | Public Sans 600 | card heading, disclosure trigger |
| `--t-body` | `1rem` / 1.6 | Public Sans 400 | prose |
| `--t-label` | `0.875rem` / 1.4 | Public Sans 500 | input labels |
| `--t-caption` | `0.8125rem` / 1.45 | Public Sans 400, `--ink-muted` | helper, source, timestamps |
| `--t-mono-table` | `0.875rem` | Public Sans 400 + tabular | amortization table |

Weight ceiling is **600**. No 700, no 800. Hierarchy comes from size, color, and space — never from bolder-and-bolder.

### 3.3 Loading

- One variable file per family, `woff2`, Latin subset.
- `next/font` with automatic `size-adjust` fallback metrics → CLS from font swap must be **0**.
- Preload **Newsreader only** (it renders the LCP element). Public Sans loads normally.
- `font-display: swap`.

---

## 4. Space, radius, motion

**Space** — 4px base, 8pt rhythm: `4, 8, 12, 16, 24, 32, 48, 64, 96`. Section vertical rhythm is 48 (mobile) / 96 (desktop). Content max-width `72ch` for prose, `1160px` for the tool shell.

**Radius** — three values only: `--r-control: 8px` (inputs, buttons), `--r-card: 14px` (cards, chart panel), `--r-pill: 999px` (slider track/thumb, toggles). Nothing else.

**Motion** — the entire motion budget:

| Token | Value | Used for |
|---|---|---|
| `--m-fast` | `120ms cubic-bezier(.2,0,0,1)` | hover, focus, toggle state |
| `--m-base` | `200ms cubic-bezier(.2,0,0,1)` | disclosure expand, value transitions |
| `--m-reveal` | `420ms cubic-bezier(.2,0,0,1)` | chart draw-in, hero count-up — **once per result change** |

Rules:
- Animate `transform` and `opacity` only. Never `width`, `height`, `top`, or `left`.
- **No** page-load animation, entrance stagger, scroll-triggered reveal, parallax, or scroll-jacking. The result must be readable the instant it paints.
- No easing that overshoots. No bounce, no spring, no elastic.
- Everything above is wrapped in `@media (prefers-reduced-motion: no-preference)`. Under `reduce`, values snap.

---

## 5. Layout

### 5.1 The tool screen

Desktop ≥1024px:

```
┌──────────────────────────────────────────────────────────────┐
│  wordmark            Tools ▾        Country: 🇺🇸 US ▾          │  56px, hairline under
├───────────────────────────────────┬──────────────────────────┤
│  H1  Mortgage Calculator          │                          │
│  answer-first paragraph (2 lines) │                          │
│                                   │                          │
│  ┌─ RESULT CARD ────────────────┐ │      300×600             │
│  │  Monthly payment             │ │      sticky ad           │
│  │  $2,528                      │ │      (never above        │
│  │  ≈ €2,340 · ECB ref rate     │ │       the tool)          │
│  │  ─────────────────────────   │ │                          │
│  │  Total interest   $510,178   │ │                          │
│  │  Paid off         Mar 2056   │ │                          │
│  └──────────────────────────────┘ │                          │
│                                   │                          │
│  ┌─ INPUTS ─────────────────────┐ │                          │
│  │  Home price   [ 400,000    ] │ │                          │
│  │  ▬▬▬▬▬▬▬●▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ │ │                          │
│  │  Down payment [ 80,000 ][20%]│ │                          │
│  │  ▬▬▬▬▬●▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ │ │                          │
│  │  Interest rate[ 6.50     ]%  │ │                          │
│  │  Term         (15)(20)(30)yr │ │                          │
│  │  ▸ Add taxes, insurance, PMI │ │                          │
│  └──────────────────────────────┘ │                          │
├───────────────────────────────────┴──────────────────────────┤
│  ┌─ THE CROSSOVER ────────────────────────────────────────┐  │
│  │  stacked area: interest (oxblood) / principal (teal)   │  │
│  │  vertical marker + label at crossover month            │  │
│  └────────────────────────────────────────────────────────┘  │
│  [ in-content ad — exact reserved dimensions ]               │
│  How this is calculated ▸   Where the rate comes from ▸       │
│  FAQ · Methodology · Author · Embed this calculator          │
└──────────────────────────────────────────────────────────────┘
```

Mobile <768px: single column, order = H1 → answer paragraph → **result card** → inputs → chart → disclosures. The result card is above the fold on a 390×844 viewport. Once it scrolls out of view, a 56px sticky bottom bar carries the monthly payment.

### 5.2 Hard layout rules

- **No hero section.** No full-bleed banner, no oversized marketing headline, no illustration. The H1 and the answer paragraph are the top of the page, and the result card starts within the first viewport.
- **No submit button.** Results recalculate on every input change, debounced 120ms.
- **Never centered.** Text is left-aligned inside centered containers.
- **No three-column feature grid** anywhere on a tool page.
- Ad slots render as reserved boxes with exact fixed dimensions from first paint. Max 2 per page. Never above the tool.

---

## 6. Components

### 6.1 Result card
The single most important object. White `--surface`, `--r-card`, 1px `--rule`, 24/32 padding. Primary figure at `--t-hero` in `--ink`. Secondary figures at `--t-figure`, separated by a hairline, labels above values in `--t-label` `--ink-muted`. Wrapped in `aria-live="polite"` with `aria-atomic="true"`. On value change: numerals count up over `--m-reveal` (reduced motion → snap).

### 6.2 Slider + numeric hybrid
Every continuous input is **both** a native `<input type="range">` and a native `<input type="text" inputmode="decimal">`, bound to the same state. Neither is decorative; either can drive.
- Track 4px `--surface-sunken`, filled portion `--ink`, thumb 24px `--surface` with 2px `--ink` border, `--r-pill`.
- Touch target ≥44px (pad the track, don't grow the thumb).
- Numeric field is right-aligned, tabular, with the currency symbol or unit as a static adornment inside the field.
- Slider is for exploring. The field is for precision. Never ship one without the other.

### 6.3 Segmented control
For term (15/20/30) and repayment frequency. Native radios, visually a `--r-pill` group with `--ink` fill on the selected item. Arrow-key navigable.

### 6.4 Disclosure ("Add taxes, insurance, PMI")
Native `<details>`/`<summary>`, or Radix Accordion. Closed by default. `--t-h3` trigger with a rotating chevron. Height animates via `grid-template-rows` at `--m-base`. **Everything a typical user needs must be visible before opening it** — the disclosure holds refinements, never requirements.

### 6.5 Country selector
Header-right, always visible on every page. It is **navigation, not a form field** — a real `<a>` link per country so crawlers follow it.
- Trigger: flag glyph + ISO code + chevron. On desktop, a two-column popover of all 12; on mobile, a full-height sheet.
- Switching navigates to `/{cc}/mortgage-calculator` and **preserves inputs via the URL permalink**, converting no values — the amount stays `400,000`, the currency label changes. State this in copy (see content file).
- A geo-suggestion banner may appear once, dismissible, above the result card. **Never auto-redirect.**
- The footer carries a plain crawlable list of all 12 country links regardless.

### 6.6 Currency display toggle
Distinct from the country selector and visually subordinate to it.
- Lives inside the result card as a small `--t-caption` control: `≈ €2,340 · ECB reference rate · 27 Jul` with the currency as an inline dropdown.
- Changing it changes **only that line**. It never touches the calculation. This must be obvious from the visual hierarchy: the converted figure is `--ink-muted`, one size below `--t-figure`, and sits below a hairline.
- The rate date and source are always visible, not hidden in a tooltip. An `ⓘ` opens the fuller explanation.
- Default state: off for domestic visitors, on for a visitor whose geo currency differs from the page currency.

### 6.7 Validation
Inline, below the field, `--danger` text plus an icon. Never a modal, never a toast, never a red-filled field. Errors state what happened and what to do. Out-of-range slider values clamp silently; only typed values can error.

### 6.8 Ad slot
A `--surface-sunken` box at exact final dimensions with a `--t-caption` `--ink-faint` "Advertisement" label, rendered server-side before any ad script runs. It occupies its space at first paint whether or not an ad fills.

---

## 7. Charts

### 7.1 The Crossover (flagship)
Stacked area, x = years, y = cumulative payment split. Interest `--interest` / `--interest-soft` below, principal `--principal` / `--principal-soft` above. A 1px `--ink` vertical rule at the crossover month with a small label: *"Year 18 — you start paying more principal than interest."*
- Series are **directly labelled at their right edge**. No legend.
- Draw-in on `--m-reveal`: the areas clip-path reveal left-to-right, the marker fades in last. On subsequent input changes, the shape tweens over `--m-base`.

### 7.2 Balance decline
Simple line, `--principal`, with a dotted horizontal reference at 80% LTV labelled *"PMI typically drops off here"* (US) or the local equivalent.

### 7.3 Overpayment comparison
Two bars or two lines: base in `--ink-faint`, scenario in `--scenario`. Always paired with a plain-language sentence stating the difference — the sentence is the finding, the chart is the evidence.

### 7.4 Chart rules
- **SVG only.** No Canvas, no WebGL, no 3D, no donut with a number in the middle, no gauges.
- Recharts (default) or visx (if minimizing bundle). `dynamic()` imported so it never blocks the hero LCP. The chart container reserves its exact aspect ratio before load.
- Accessibility: `role="img"` + a descriptive `aria-label` summarizing the finding in words, decorative children `aria-hidden`, and a visually-hidden `<table>` carrying the same data.
- Axes: `--ink-faint` ticks, no gridlines except one hairline `--rule` at the baseline. Currency formatted per locale, abbreviated on mobile (`$400k`).
- Max 2 charts per tool page.

---

## 8. Performance budget — these are pass/fail

| Metric | Budget | Enforcement |
|---|---|---|
| JS, gzip, tool route | **< 150KB** | `size-limit` in CI, build fails over |
| LCP | **< 2.0s** | field p75, CrUX |
| INP | **< 160ms** | field p75 |
| CLS | **< 0.05** | field p75 |
| Lighthouse (mobile) | **≥ 95** all four | CI |
| Fonts | 2 files, ≤ 40KB total | build check |

Animation library: CSS/WAAPI first. If Motion is used at all, it is `LazyMotion` + `m` (~5KB), for the result reveal only. No GSAP. No Lottie. No scroll libraries.

---

## 9. Prohibited — the generated-design tells

Producing any of these means the design has failed its brief:

- Inter, Poppins, or Montserrat as the primary face
- Indigo/violet/purple accents, or any gradient (background, text, button, or chart)
- Glassmorphism, frosted blur, or translucent panels
- Three centered feature cards with icons above headings
- Emoji in headings, labels, or buttons
- Gradient or glow on numbers
- A full-bleed hero with a centered marketing headline and two CTAs
- Bounce, spring, or elastic easing
- Scroll-triggered reveals, parallax, scroll-jacking, or page-load stagger
- Generic stock or isometric illustration
- Nested cards (a card inside a card inside a card)
- Drop shadows used as the primary means of separation
- Dark background with a single acid-green accent (the current default "premium" look)
- Any color used decoratively that also carries meaning in the charts

---

## 10. Accessibility floor

Native elements wherever one exists. Visible focus ring (`--focus`, 2px, 2px offset) on every interactive element. Full keyboard operation including sliders and the country selector. `aria-live` on results. All motion gated on `prefers-reduced-motion`. Contrast verified at AA. Touch targets ≥44px. Charts have text alternatives. The page must be fully usable with JavaScript disabled down to at least the static prefilled example result.
